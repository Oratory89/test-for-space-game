#define INCBIN_PREFIX _ib
#define INCBIN_STYLE INCBIN_STYLE_SNAKE
#include "brl.mod/blitz.mod/incbin/incbin.h"
// FILE : "\\Textures\\Ground.bmp"	bd1e60cfb6175c6e
// FILE : "\\Textures\\Dude.bmp"	bb6c46c25d81833c
// ----
INCBIN(_bb_main_1, "d:/blitz max stuff/Textures/Ground.bmp");
INCBIN(_bb_main_2, "d:/blitz max stuff/Textures/Dude.bmp");